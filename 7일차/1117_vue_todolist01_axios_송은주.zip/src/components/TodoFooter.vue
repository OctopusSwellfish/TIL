<template>
    <div class="clearAllContainer">
        <span class="clearAllBtn" @click="clearTodo">Clear All</span>
    </div>
</template>

<script>
    import http from '../http-common';
    export default {
        methods: {
            clearTodo() {
                http.delete('/todolist/user/java')
                        .then(()=>{ alert("할일 목록을 삭제하였습니다."); })
                        .catch(()=>{ alert("할일 목록 삭제에 실패하였습니다."); });
            }
        }
    }
</script>

<style scoped>
.clearAllContainer {
    width: 8.5rem;
    height: 50px;
    line-height: 50px;
    background-color: white;
    border-radius: 5px;
    margin: 0 auto;
}
.clearAllBtn {
    color: #e20303;
    /* 추가 */
    display: block;
}
</style>